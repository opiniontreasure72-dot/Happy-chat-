
/**
 * Happy Chat Firebase service layer.
 * The existing index.html Firebase initialization remains compatible.
 * These helpers are intentionally defensive so the UI can work while
 * individual Firebase features are configured.
 */
window.HappyChatFirebase = {
  get db() { return window.db || null; },
  get auth() { return window.auth || null; },
  get storage() { return window.storage || null; },

  async currentUser() {
    if (window.currentUser) return window.currentUser;
    return new Promise(resolve => {
      const auth = this.auth;
      if (!auth || typeof auth.onAuthStateChanged !== "function") return resolve(null);
      const off = auth.onAuthStateChanged(u => { off && off(); resolve(u); });
    });
  },

  async userToken() {
    const u = await this.currentUser();
    return u ? u.getIdToken() : null;
  }
};
