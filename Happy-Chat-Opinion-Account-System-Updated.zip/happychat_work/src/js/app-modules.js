
window.HappyChatModules = {
  features: {
    feed: true, profiles: true, messaging: true, notifications: true,
    search: true, stories: true, moderation: true, admin: true,
    opinion: true, voice: true, vision: true, files: true,
    webSearch: true, imageGeneration: true, darkMode: true
  },
  version: "3.0.0"
};
