/**
 * Happy Chat production social data layer.
 * Firestore is the source of truth; localStorage is used only for UI preferences.
 */
(function(){
  const db = () => window.db;
  const auth = () => window.auth;
  const fs = () => window.firebase;
  const user = () => window.currentUser;
  const clean = s => String(s || '').trim();
  const uid = () => user() && user().uid;

  function requireUser(){ if(!uid()) throw new Error('Please sign in first.'); return user(); }
  function now(){ return fs().firestore.FieldValue.serverTimestamp(); }
  function notify(targetUid, type, payload){
    if(!targetUid || targetUid === uid()) return Promise.resolve();
    return db().collection('notifications').add({
      uid: targetUid, actorUid: uid(), actorEmail: user().email || '', type,
      ...payload, read:false, createdAt:now()
    });
  }

  window.HappyChatSocial = {
    async ensureProfile(extra={}){
      const u=requireUser();
      const ref=db().collection('profiles').doc(u.uid);
      const snap=await ref.get();
      if(!snap.exists){
        await ref.set({uid:u.uid,email:u.email||'',displayName:(u.email||'User').split('@')[0],bio:'',photoURL:u.photoURL||'',followersCount:0,followingCount:0,createdAt:now(),updatedAt:now(),...extra});
      }
      return (await ref.get()).data();
    },
    async updateProfile(data){
      const u=requireUser();
      const allowed={displayName:clean(data.displayName).slice(0,60),username:clean(data.username).replace(/[^a-zA-Z0-9_.-]/g,'').slice(0,30).toLowerCase(),bio:clean(data.bio).slice(0,300),photoURL:clean(data.photoURL).slice(0,1000),updatedAt:now()};
      await db().collection('profiles').doc(u.uid).set(allowed,{merge:true});
      return this.ensureProfile();
    },
    async toggleLike(postId){
      const u=requireUser(); const ref=db().collection('posts').doc(postId);
      const snap=await ref.get(); if(!snap.exists) throw new Error('Post not found.');
      const p=snap.data(), liked=!!(p.reactions||{})[u.uid];
      await ref.update({[`reactions.${u.uid}`]:liked?fs().firestore.FieldValue.delete():1});
      if(!liked) await notify(p.uid,'like',{postId});
      return !liked;
    },
    async addComment(postId,text){
      const u=requireUser(); text=clean(text); if(!text||text.length>300) throw new Error('Comment must be 1–300 characters.');
      const ref=db().collection('posts').doc(postId), snap=await ref.get(); if(!snap.exists) throw new Error('Post not found.');
      await ref.update({comments:fs().firestore.FieldValue.arrayUnion({uid:u.uid,user:u.email||'',text,time:Date.now()})});
      await notify(snap.data().uid,'comment',{postId,text:text.slice(0,120)});
    },
    async follow(targetUid){
      const u=requireUser(); if(!targetUid||targetUid===u.uid) return false;
      const ref=db().collection('follows').doc(u.uid+'_'+targetUid), snap=await ref.get();
      if(snap.exists){ await ref.delete(); return false; }
      await ref.set({followerUid:u.uid,followingUid:targetUid,createdAt:now()});
      await notify(targetUid,'follow',{}); return true;
    },
    async savePost(postId){
      const u=requireUser(), ref=db().collection('savedPosts').doc(u.uid+'_'+postId), snap=await ref.get();
      if(snap.exists){await ref.delete();return false;} await ref.set({uid:u.uid,postId,createdAt:now()});return true;
    },
    async markNotificationRead(id){ return db().collection('notifications').doc(id).update({read:true}); },
    async mute(targetUid){ return db().collection('mutes').doc(uid()+'_'+targetUid).set({uid:uid(),targetUid,createdAt:now()}); },
    async block(targetUid){ return db().collection('blocks').doc(uid()+'_'+targetUid).set({uid:uid(),targetUid,createdAt:now()}); },
    async report(itemId,reason){
      const u=requireUser(); return db().collection('reports').add({reporterUid:u.uid,itemId:String(itemId),reason:clean(reason).slice(0,500),status:'open',createdAt:now()});
    },
    async sendDirectMessage(targetUid,text){
      const u=requireUser(); text=clean(text); if(!targetUid||!text||text.length>2000) throw new Error('Invalid message.');
      const ids=[u.uid,targetUid].sort(), conversationId=ids.join('_');
      await db().collection('conversations').doc(conversationId).set({members:ids,updatedAt:now(),lastMessage:text.slice(0,200)}, {merge:true});
      return db().collection('conversations').doc(conversationId).collection('messages').add({senderUid:u.uid,senderEmail:u.email||'',text,createdAt:now(),readBy:[u.uid]});
    },
    conversationId(targetUid){ const ids=[uid(),targetUid].sort(); return ids.join('_'); },
    listenNotifications(cb){
      if(!uid()) return ()=>{};
      return db().collection('notifications').where('uid','==',uid()).limit(30).onSnapshot(s=>cb(s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.toMillis?.()||0)-(a.createdAt?.toMillis?.()||0))));
    }
  };
})();
