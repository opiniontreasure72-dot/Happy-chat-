// Opinion text-to-speech endpoint (requires a signed-in Firebase user).
const { guard } = require("./_lib");

module.exports = async (req, res) => {
  const user = await guard(req, res, { limitName: "speak", max: 20, windowMs: 60_000, maxBody: 64 * 1024 });
  if (!user) return;
  try {
    const text = String((req.body || {}).text || "").trim().slice(0, 4096);
    if (!text) return res.status(400).json({ error: "No text" });
    const upstream = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + process.env.OPENAI_API_KEY
      },
      body: JSON.stringify({
        model: process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts",
        voice: process.env.OPENAI_TTS_VOICE || "alloy",
        input: text,
        response_format: "mp3"
      })
    });
    if (!upstream.ok) return res.status(502).json({ error: "Speech generation failed." });
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).send(buf);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "Speech generation failed." });
  }
};
