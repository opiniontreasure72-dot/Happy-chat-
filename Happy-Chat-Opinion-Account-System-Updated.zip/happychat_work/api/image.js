// Opinion image generation endpoint (requires a signed-in Firebase user).
const { guard } = require("./_lib");

module.exports = async (req, res) => {
  const user = await guard(req, res, { limitName: "image", max: 5, windowMs: 60_000, maxBody: 64 * 1024 });
  if (!user) return;
  try {
    const prompt = String((req.body || {}).prompt || "").trim().slice(0, 4000);
    if (!prompt) return res.status(400).json({ error: "No image prompt" });
    const upstream = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + process.env.OPENAI_API_KEY
      },
      body: JSON.stringify({
        model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2",
        prompt,
        size: "1024x1024",
        quality: "auto"
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: "Image generation failed." });
    const item = data.data && data.data[0];
    return res.status(200).json({
      image: item ? (item.b64_json ? "data:image/png;base64," + item.b64_json : item.url) : null
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "Image generation failed." });
  }
};
