// Shared helpers for Opinion API endpoints.
// Files starting with "_" inside /api are NOT exposed as routes by Vercel.

const crypto = require("crypto");

// ---- CORS -----------------------------------------------------------
// The site calls /api/* from its own origin, so no CORS header is needed.
// Only set one when ALLOWED_ORIGIN is configured (comma-separated list OK).
function cors(req, res) {
  const allowed = (process.env.ALLOWED_ORIGIN || "")
    .split(",").map(s => s.trim()).filter(Boolean);
  const origin = req.headers.origin;
  if (allowed.length && origin && allowed.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
}

// ---- Auth -----------------------------------------------------------
let adminApp = null;
function getAdmin() {
  const admin = require("firebase-admin");
  if (!adminApp) {
    adminApp = admin.apps.length
      ? admin.app()
      : admin.initializeApp({
          credential: admin.credential.cert(
            JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
          )
        });
  }
  return admin;
}

async function verifyFirebaseToken(req) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token) throw new Error("AUTH_REQUIRED");

  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    try {
      return await getAdmin().auth().verifyIdToken(token);
    } catch (e) {
      throw new Error("AUTH_REQUIRED");
    }
  }
  // Explicit opt-in for local development only.
  if (process.env.ALLOW_UNVERIFIED_FIREBASE === "true" && !process.env.VERCEL_ENV) {
    return { uid: "unverified" };
  }
  throw new Error("AUTH_SERVER_NOT_CONFIGURED");
}

// ---- Best-effort rate limit ------------------------------------------
// In-memory, per server instance: it slows abuse but is NOT a hard limit
// on serverless. Use Upstash/Vercel KV for a strict global limit.
const buckets = new Map();
function rateLimit(uid, name, max, windowMs) {
  const key = name + ":" + uid;
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || now > b.reset) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    if (buckets.size > 5000) {
      for (const [k, v] of buckets) if (now > v.reset) buckets.delete(k);
    }
    return true;
  }
  b.count++;
  return b.count <= max;
}

// ---- Common request guard -------------------------------------------
// Returns the verified user, or null after sending an error response.
async function guard(req, res, { limitName, max, windowMs, maxBody }) {
  cors(req, res);
  if (req.method === "OPTIONS") { res.status(204).end(); return null; }
  if (req.method !== "POST") { res.status(405).json({ error: "Method not allowed" }); return null; }
  const size = Number(req.headers["content-length"] || 0);
  if (Number.isFinite(size) && size > maxBody) { res.status(413).json({ error: "Request too large" }); return null; }
  if (!process.env.OPENAI_API_KEY) { res.status(503).json({ error: "This feature is not configured yet." }); return null; }
  try {
    const user = await verifyFirebaseToken(req);
    if (!rateLimit(user.uid, limitName, max, windowMs)) {
      res.status(429).json({ error: "Too many requests. Please slow down." });
      return null;
    }
    return user;
  } catch (err) {
    const notConfigured = err.message === "AUTH_SERVER_NOT_CONFIGURED";
    res.status(notConfigured ? 500 : 401).json({
      error: notConfigured
        ? "Server authentication is not configured. Add FIREBASE_SERVICE_ACCOUNT_JSON in Vercel."
        : "Please sign in first."
    });
    return null;
  }
}

module.exports = { cors, verifyFirebaseToken, rateLimit, guard, crypto };
